function Inicio() {
    return (
      <div>
        <h1>Esta es la página de inicio</h1>
      </div>
    );
  }
  
  export default Inicio;