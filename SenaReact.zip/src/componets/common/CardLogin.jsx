import { Box } from "@mui/material";

function CardLogin() {
    return (
        <>
            <Box>
                <h1>Pagina de login</h1>
            </Box>
        </>
    )
}

export default CardLogin